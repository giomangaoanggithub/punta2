<?php

include 'zerver_entrance.php';

session_start();

error_reporting(0);

$email = $_SESSION["curr_email_user"];
$admin = $_POST["compadmin"];

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "INSERT INTO admin_teacher_conn (admin_email, teacher_email, connection)
    VALUES ('$admin', '$email', '0')";
    // use exec() because no results are returned
    $conn->exec($sql);
    echo "Please wait for your teacher to respond.";
  } catch(PDOException $e) {
    echo $sql . "<br>" . $e->getMessage();
  }
  
  $conn = null;
?>