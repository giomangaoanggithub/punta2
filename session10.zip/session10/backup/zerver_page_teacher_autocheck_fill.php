<?php
include 'zerver_entrance.php';

session_start();

$email = $_SESSION["curr_email_user"];

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $sql = "UPDATE created_questions SET checking_param = '<!@#CORRECT$%^><&*>0<&*>0<&*>0<&*>0<&*>0<&*>0<&*>0<&*>Speed refers to an object travel distance over time, while velocity is basically speed with an inclusion of direction or known as a vector. As for the distance and displacement, both are similar, but the core difference is that the distance tells how much ground an object has covered, while displacement shows how far out of place an object is.<&*>Speed  and  distance  are  scalar  quantities,  in  other  words,  they  only  consider  size,  while  speed  and  displacement  are  vector  quantities,  which  consider  not  only  size  but  also  direction  of  the  object.  <&*>Speed  and  distance  are  scalar  quantities,  in  other  words,  they  only  consider  size,  while  speed  and  displacement  are  vector  quantities,  which  consider  not  only  size  but  also  direction  of  the  object.  <&*>Speed  and  distance  are  scalar  quantities,  in  other  words,  they  only  consider  size,  while  speed  and  displacement  are  vector  quantities,  which  consider  not  only  size  but  also  direction  of  the  object.  <&*>Speed  and  distance  are  scalar  quantities,  in  other  words,  they  only  consider  size,  while  speed  and  displacement  are  vector  quantities,  which  consider  not  only  size  but  also  direction  of  the  object.  <&*>Speed  and  distance  are  scalar  quantities,  in  other  words,  they  only  consider  size,  while  speed  and  displacement  are  vector  quantities,  which  consider  not  only  size  but  also  direction  of  the  object.  <&*>Speed  and  distance  are  scalar  quantities,  in  other  words,  they  only  consider  size,  while  speed  and  displacement  are  vector  quantities,  which  consider  not  only  size  but  also  direction  of  the  object.' WHERE owner_teacher = '$email' AND question_id = '64'";

  // Prepare statement
  $stmt = $conn->prepare($sql);

  // execute the query
  $stmt->execute();

  // echo a message to say the UPDATE succeeded
  echo 'Simulating if the teacher writes an expexcted answer in the auto checking feature.';

} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;
?>