<?php

session_start();

echo $_SESSION["teacher_pick_room"];

?>