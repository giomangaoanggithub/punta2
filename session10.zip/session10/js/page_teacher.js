company_off = "";
company_off;

function on(input) {
  document.getElementById("overlay").style.display = "block";
  if (input == 1) {
    document.getElementById("delete_r-modal").style.display = "flex";
  } else if (input == 2) {
    document.getElementById("company_src-modal").style.display = "flex";
  } else if (input == 3) {
    document.getElementById("company_queue-modal").style.display = "flex";
  }
}

function off() {
  settle_del_r = "";
  if (company_off != "") {
    document.getElementById("overlay").style.display = "none";
  }
}

var fetch_rooms = "";
var fetch_newstud = "";
var fetch_cq = "";
var fetch_innerview_stud = "";
var fetch_curr_updating_q = "";
var fetch_student_answers = "";

$("#accept-company").click(function () {
  if (
    document.getElementById("search-company").value == "" ||
    document.getElementById("company-code").value == ""
  ) {
    alert("Please enter existing company and its company code...");
    return;
  }
  $.post(
    "php/zerver_page_teacher_fetch_company_admin.php",
    {
      compname: document.getElementById("search-company").value,
      compcode: document.getElementById("company-code").value,
    },
    function (data) {
      data = JSON.parse(data);
      if (data.length == 0) {
        alert(
          "Sorry, you've just entered wrong room code or non-existent company..."
        );
        return;
      }
      $.post(
        "php/zerver_page_teacher_req_company.php",
        {
          compadmin: data[0]["company_admin_email"],
        },
        function () {
          document.getElementById("company_src-modal").style.display = "none";
          document.getElementById("company_queue-modal").style.display = "flex";
        }
      );
    }
  );
});

function page_fetch_data() {
  $.get("php/zerver_page_teacher_fetch_company_src.php", function (data) {
    data = JSON.parse(data);
    if (data.length == 0) {
      on(2);
    } else {
      if (data[0]["connection"] == "0") {
        on(3);
      }
      $.get("php/zerver_page_teacher_fetch_self.php", function (data) {
        data = JSON.parse(data);
        document.getElementById("profile-name-email").innerHTML =
          "Name: " +
          data[0]["username"] +
          "<br>Email: " +
          data[0]["email"] +
          "<br>Role: Teacher";
        document.getElementById("profile-pic").src =
          "php/" + data[0]["profile_pic_address"];
      });
      $.get("php/zerver_page_teacher_fetch_company.php", function (data) {
        data = JSON.parse(data);
        document.getElementById("company-title").innerHTML =
          data[0]["company_name"];
      });
      $.get(
        "php/zerver_page_teacher_fetch_student_answers.php",
        function (data) {
          fetch_student_answers = JSON.parse(data);
          $.get("php/zerver_page_teacher_fetch_rooms.php", function (data) {
            fetch_rooms = JSON.parse(data);
            $.get(
              "php/zerver_page_teacher_fetch_newstuds.php",
              function (data) {
                fetch_newstud = JSON.parse(data);
                $.get(
                  "php/zerver_page_teacher_fetch_questions.php",
                  function (data) {
                    fetch_cq = JSON.parse(data);
                    page_start();
                  }
                );
              }
            );
          });
        }
      );
    }
  });
}

function page_fetch_grades() {
  $.get(
    "php/zerver_page_teacher_fetch_students_innerview.php",
    function (data) {
      fetch_innerview_stud = JSON.parse(data);
    }
  );
  $.get(
    "php/zerver_page_teacher_fetch_students_classrooms.php",
    function (data) {
      data = JSON.parse(data);
      $("#grades-students").empty();
      for (i in data) {
        $("#grades-students").append(
          "<tr onclick='innerview_one_student(" +
            '"' +
            data[i]["email"] +
            '"' +
            ")'><td><img src='php/" +
            data[i]["profile_pic_address"] +
            "' class='people-pic img-fluid'></td><td>" +
            data[i]["username"] +
            "</td></tr>"
        );
      }
    }
  );
}

function innerview_one_student(input) {
  $("#grades-innerview").empty();
  for (i in fetch_innerview_stud) {
    if (input == fetch_innerview_stud[i]["owner_student"]) {
      $("#grades-innerview").append(
        "<tr><td>" +
          fetch_innerview_stud[i]["room_name"] +
          "</td><td><b>" +
          fetch_innerview_stud[i]["question"] +
          "</b><br><br>" +
          fetch_innerview_stud[i]["answer"] +
          "</td><td>" +
          fetch_innerview_stud[i]["grades"] +
          "</td></tr>"
      );
    }
  }
}

function edit_question(input) {
  fetch_curr_updating_q = input;
  x = 0;
  while (x < fetch_cq.length && fetch_cq[x]["question_id"] != input) {
    x++;
  }
  document.getElementById("create-q").value = fetch_cq[x]["question"];
  document.getElementById("type-essay-q").value = fetch_cq[x]["type_question"];
  document.getElementById("hps-input").value = fetch_cq[x]["HPS"];
  document.getElementById("due-input").value = fetch_cq[x]["due_date"];
  document.getElementById("submit-q").style.display = "none";
  document.getElementById("resubmit-q").style.display = "inline";
  document.getElementById("cancel-q-up").style.display = "inline";
  if (document.getElementById("type-essay-q").value == "factual-recall") {
    document.getElementById("topic-q-label").style.display = "flex";
    document.getElementById("list-important").style.display = "flex";
    document.getElementById("list-important").value = "value from db";
  } else if (document.getElementById("type-essay-q").value == "response") {
    document.getElementById("topic-q-label").style.display = "none";
    document.getElementById("list-important").style.display = "none";
  }
}

function cancel_edit_question() {
  fetch_curr_updating_q = "";
  document.getElementById("submit-q").style.display = "inline";
  document.getElementById("resubmit-q").style.display = "none";
  document.getElementById("cancel-q-up").style.display = "none";
  document.getElementById("topic-q-label").style.display = "none";
  document.getElementById("list-important").style.display = "none";
  document.getElementById("create-q").value = "";
  document.getElementById("type-essay-q").value = "response";
  document.getElementById("hps-input").value = "10";
  document.getElementById("due-input").value = "";
  document.getElementById("list-important").value = "";
}

$("#teacher-sub-bar-tab1").click(function () {
  document.getElementById("teacher-rooms").style.display = "flex";
  document.getElementById("teacher-sub-bar-tab1").style.backgroundColor =
    "#5cdb95";
  document.getElementById("teacher-create").style.display = "none";
  document.getElementById("teacher-sub-bar-tab2").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-grades").style.display = "none";
  document.getElementById("teacher-sub-bar-tab3").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab1-1").style.backgroundColor =
    "#5cdb95";
  document.getElementById("teacher-sub-bar-tab2-2").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab3-3").style.backgroundColor =
    "#379683";

  $("#thead-lor").empty();
  $("#thead-lor").append(
    "<tr><td>room name</td><td>room code</td><td>students</td><td>action</td></tr>"
  );
  $("#tbody-lor").empty();
  for (i in fetch_rooms) {
    $("#tbody-lor").append(
      "<tr><td><img src='images/loading.gif' style='display: none; height: 30px' class='chosen_rooms' id='chosen_room_" +
        fetch_rooms[i]["room_id"] +
        "'>" +
        fetch_rooms[i]["room_name"] +
        "</td><td>" +
        fetch_rooms[i]["room_code"] +
        "</td><td class='see-room-studs-h'>" +
        "##" + //fetch_rooms[i][""]
        "<i class='see-room-studs material-icons'>visibility</i></td><td><i class='enter-room material-icons' onclick='room_enter(" +
        fetch_rooms[i]["room_id"] +
        ")'>meeting_room</i><i class='edit-room material-icons'>edit</i><i onclick='delete_room(" +
        fetch_rooms[i]["room_id"] +
        ")' class='delete-room material-icons'>delete</i></td></tr>"
    );
  }
  $("#thead-newstud").empty();
  $("#thead-newstud").append(
    "<tr><th>action</th><th>time of issue</th><th>room name</th><th>new students</th></tr>"
  );
  $("#tbody-newstud").empty();
  for (i in fetch_newstud) {
    $("#tbody-newstud").append(
      "<tr><td>" +
        "<i class='decline-stud material-icons' onclick='newstud_reject(" +
        fetch_newstud[i]["t_s_conn_id"] +
        ")'>close</i><i class='accept-stud material-icons' onclick='newstud_accept(" +
        fetch_newstud[i]["t_s_conn_id"] +
        ")'>how_to_reg</i>" +
        "</td><td>" +
        fetch_newstud[i]["time_of_issue"] +
        "</td><td>" +
        fetch_newstud[i]["room_name"] +
        "</td><td>" +
        fetch_newstud[i]["student_email"] +
        "<img src='images/loading.gif' id='loading_newstud_" +
        fetch_newstud[i]["t_s_conn_id"] +
        "' style='height: 30px; display: none'></td><tr>"
    );
  }
});

$("#teacher-sub-bar-tab2").click(function () {
  document.getElementById("teacher-rooms").style.display = "none";
  document.getElementById("teacher-sub-bar-tab1").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-create").style.display = "flex";
  document.getElementById("teacher-sub-bar-tab2").style.backgroundColor =
    "#5cdb95";
  document.getElementById("teacher-grades").style.display = "none";
  document.getElementById("teacher-sub-bar-tab3").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab1-1").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab2-2").style.backgroundColor =
    "#5cdb95";
  document.getElementById("teacher-sub-bar-tab3-3").style.backgroundColor =
    "#379683";
  $("#thead-cq").empty();
  $("#thead-cq").append(
    "<tr><th>questions</th><th>HPS</th><th>time of issue</th><th>due date</th><th>status</th><th>actions</th></tr>"
  );
});

$("#teacher-sub-bar-tab3").click(function () {
  document.getElementById("teacher-rooms").style.display = "none";
  document.getElementById("teacher-sub-bar-tab1").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-create").style.display = "none";
  document.getElementById("teacher-sub-bar-tab2").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-grades").style.display = "flex";
  document.getElementById("teacher-sub-bar-tab3").style.backgroundColor =
    "#5cdb95";
  document.getElementById("teacher-sub-bar-tab1-1").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab2-2").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab3-3").style.backgroundColor =
    "#5cdb95";
});

$("#teacher-sub-bar-tab1-1").click(function () {
  document.getElementById("teacher-sub-bar-tab1").style.backgroundColor =
    "#5cdb95";
  document.getElementById("teacher-sub-bar-tab2").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab3").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-rooms").style.display = "flex";
  document.getElementById("teacher-create").style.display = "none";
  document.getElementById("teacher-grades").style.display = "none";
  document.getElementById("teacher-sub-bar-tab1-1").style.backgroundColor =
    "#5cdb95";
  document.getElementById("teacher-sub-bar-tab2-2").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab3-3").style.backgroundColor =
    "#379683";
  document.getElementById("room-title-create-q").innerHTML == "Room: ";
  for (x = 0; document.getElementsByClassName("chosen_rooms").length; x++) {
    document.getElementsByClassName("chosen_rooms")[x].style.display = "none";
  }
});

$("#teacher-sub-bar-tab2-2").click(function () {
  document.getElementById("teacher-sub-bar-tab1").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab2").style.backgroundColor =
    "#5cdb95";
  document.getElementById("teacher-sub-bar-tab3").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-rooms").style.display = "none";
  document.getElementById("teacher-create").style.display = "flex";
  document.getElementById("teacher-grades").style.display = "none";
  document.getElementById("teacher-sub-bar-tab1-1").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab2-2").style.backgroundColor =
    "#5cdb95";
  document.getElementById("teacher-sub-bar-tab3-3").style.backgroundColor =
    "#379683";
  $("#thead-cq").empty();
  $("#thead-cq").append(
    "<tr><th>questions</th><th>HPS</th><th>time of issue</th><th>due date</th><th>status</th><th>actions</th></tr>"
  );
});

$("#teacher-sub-bar-tab3-3").click(function () {
  document.getElementById("teacher-sub-bar-tab1").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab2").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab3").style.backgroundColor =
    "#5cdb95";
  document.getElementById("teacher-rooms").style.display = "none";
  document.getElementById("teacher-create").style.display = "none";
  document.getElementById("teacher-grades").style.display = "flex";
  document.getElementById("teacher-sub-bar-tab1-1").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab2-2").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab3-3").style.backgroundColor =
    "#5cdb95";
  document.getElementById("room-title-create-q").innerHTML == "Room: ";
});

$("#r-delete").click(function () {
  document.getElementById("delete_r_loady").style.display = "inline";
  $.post(
    "php/zerver_page_teacher_delete_room.php",
    { delete_r: document.getElementById("r-delete").value },
    function (data) {
      alert(data);
      location.reload();
    }
  );
});

// $("#type-essay-q").onchange(function () {
//   if (document.getElementById().value == "response") {
//     document.getElementById("topic-q-label").style.display = "none";
//     document.getElementById("list-important").style.display = "none";
//   } else {
//     document.getElementById("topic-q-label").style.display = "inline";
//     document.getElementById("list-important").style.display = "inline";
//   }

// });

function type_q() {
  if (document.getElementById("type-essay-q").value == "response") {
    document.getElementById("topic-q-label").style.display = "none";
    document.getElementById("list-important").style.display = "none";
  } else {
    document.getElementById("topic-q-label").style.display = "inline";
    document.getElementById("list-important").style.display = "inline";
  }
}

function submit_question() {
  if (document.getElementById("room-title-create-q").innerHTML == "Room: ") {
    alert("Please pick or create a room...");
    return;
  }
  if (document.getElementById("create-q").value == "") {
    alert("Please write a question...");
    return;
  }
  document.getElementById("submit-q-loading").style.display = "inline";
  $.post(
    "php/zerver_page_teacher_submit_question.php",
    {
      question: document.getElementById("create-q").value,
      type: document.getElementById("type-essay-q").value,
      items: document.getElementById("list-important").value,
      room: curr_room,
      hps: document.getElementById("hps-input").value,
      due_date: document.getElementById("due-input").value,
    },
    function (data) {
      alert(data);
      $.get("php/zerver_page_teacher_fetch_questions.php", function (data) {
        fetch_cq = JSON.parse(data);
        $("#tbody-cq").empty();
        for (i in fetch_cq) {
          if (
            fetch_cq[i]["publish"] == "1" &&
            fetch_cq[i]["classroom_id"] == curr_room
          ) {
            $("#tbody-cq").append(
              "<tr><td>" +
                fetch_cq[i]["question"] +
                "</td><td>" +
                fetch_cq[i]["HPS"] +
                "</td><td>" +
                fetch_cq[i]["time_of_issue"] +
                "</td><td>" +
                fetch_cq[i]["due_date"] +
                "</td><td>" +
                "PUBLISHED" +
                "</td><td><img src='images/loading.gif' id='loading-publi_" +
                fetch_cq[i]["question_id"] +
                "' style='height: 30px; display: none;'><i class='delete-room material-icons' onclick='publish_unpublish(" +
                fetch_cq[i]["question_id"] +
                ")' data-toggle='tooltip' title='Unpublish?' >unpublished</i><i id='edit_q_" +
                fetch_cq[i]["question_id"] +
                "' class='delete-room material-icons' onclick='edit_question(" +
                fetch_cq[i]["question_id"] +
                ")'>edit</i><i class='delete-room material-icons' data-toggle='tooltip' title='Delete?' >delete</i></td></tr>"
            );
          } else if (
            fetch_cq[i]["publish"] == "0" &&
            fetch_cq[i]["classroom_id"] == curr_room
          ) {
            $("#tbody-cq").append(
              "<tr><td>" +
                fetch_cq[i]["question"] +
                "</td><td>" +
                fetch_cq[i]["HPS"] +
                "</td><td>" +
                fetch_cq[i]["time_of_issue"] +
                "</td><td>" +
                fetch_cq[i]["due_date"] +
                "</td><td>" +
                "NOT PUBLISHED" +
                "</td><td><img src='images/loading.gif' id='loading-publi_" +
                fetch_cq[i]["question_id"] +
                "' style='height: 30px; display: none;'><i class='delete-room material-icons' onclick='publish_unpublish(" +
                fetch_cq[i]["question_id"] +
                ")' data-toggle='tooltip' title='Publish?' >publish</i><i id='edit_q_" +
                fetch_cq[i]["question_id"] +
                "' class='delete-room material-icons' onclick='edit_question(" +
                fetch_cq[i]["question_id"] +
                ")'>edit</i><i class='delete-room material-icons' data-toggle='tooltip' title='Delete?' >delete</i></td></tr>"
            );
          }
        }
        document.getElementById("submit-q-loading").style.display = "none";
        document.getElementById("create-q").value = "";
      });
    }
  );
}

function room_enter(input) {
  curr_room = input;
  document.getElementById("chosen_room_" + input).style.display = "inline";
  x = 0;
  y = 0;
  while (x < fetch_rooms.length && fetch_rooms[x]["room_id"] != input) {
    x++;
  }
  while (
    y < fetch_cq.length &&
    fetch_cq[y]["classroom_id"] != fetch_rooms[x]["room_id"]
  ) {
    y++;
  }
  //alert(fetch_rooms[x]["room_name"]);
  document.getElementById("room-title-create-q").innerHTML =
    fetch_rooms[x]["room_name"];
  $("#tbody-cq").empty();
  if (y < fetch_cq.length) {
    document.getElementById("chosen_room_" + input).style.display = "inline";
    for (i in fetch_cq) {
      if (
        fetch_cq[i]["publish"] == "1" &&
        fetch_cq[i]["classroom_id"] == input
      ) {
        $("#tbody-cq").append(
          "<tr><td>" +
            fetch_cq[i]["question"] +
            "</td><td>" +
            fetch_cq[i]["HPS"] +
            "</td><td>" +
            fetch_cq[i]["time_of_issue"] +
            "</td><td>" +
            fetch_cq[i]["due_date"] +
            "</td><td>" +
            "PUBLISHED" +
            "</td><td><img src='images/loading.gif' id='loading-publi_" +
            fetch_cq[i]["question_id"] +
            "' style='height: 30px; display: none;'><i class='delete-room material-icons' onclick='publish_unpublish(" +
            fetch_cq[i]["question_id"] +
            ")' data-toggle='tooltip' title='Unpublish?' >unpublished</i><i id='edit_q_" +
            fetch_cq[i]["question_id"] +
            "' class='delete-room material-icons' onclick='edit_question(" +
            fetch_cq[i]["question_id"] +
            ")'>edit</i><i class='delete-room material-icons' data-toggle='tooltip' title='Delete?' >delete</i></td></tr>"
        );
      } else if (
        fetch_cq[i]["publish"] == "0" &&
        fetch_cq[i]["classroom_id"] == input
      ) {
        $("#tbody-cq").append(
          "<tr><td>" +
            fetch_cq[i]["question"] +
            "</td><td>" +
            fetch_cq[i]["HPS"] +
            "</td><td>" +
            fetch_cq[i]["time_of_issue"] +
            "</td><td>" +
            fetch_cq[i]["due_date"] +
            "</td><td>" +
            "NOT PUBLISHED" +
            "</td><td><img src='images/loading.gif' id='loading-publi_" +
            fetch_cq[i]["question_id"] +
            "' style='height: 30px; display: none;'><i class='delete-room material-icons' onclick='publish_unpublish(" +
            fetch_cq[i]["question_id"] +
            ")' data-toggle='tooltip' title='Publish?' >publish</i><i id='edit_q_" +
            fetch_cq[i]["question_id"] +
            "' class='delete-room material-icons' onclick='edit_question(" +
            fetch_cq[i]["question_id"] +
            ")'>edit</i><i class='delete-room material-icons' data-toggle='tooltip' title='Delete?' >delete</i></td></tr>"
        );
      }
    }
    if (window.innerWidth > 829) {
      document.getElementById("teacher-sub-bar-tab2").click();
    } else if (window.innerWidth < 830) {
      document.getElementById("teacher-sub-bar-tab2-2").click();
    }
  } else {
    if (window.innerWidth > 829) {
      document.getElementById("teacher-sub-bar-tab2").click();
    } else if (window.innerWidth < 830) {
      document.getElementById("teacher-sub-bar-tab2-2").click();
    }
    $("#tbody-cq").empty();
  }
}

curr_room = "";

function publish_unpublish(input) {
  document.getElementById("loading-publi_" + input).style.display = "inline";
  x = 0;
  while (x < fetch_cq.length && input != fetch_cq[x]["question_id"]) {
    x++;
  }
  if (fetch_cq[x]["publish"] == "1") {
    $.post(
      "php/zerver_page_teacher_question_unpublish.php",
      { id: fetch_cq[x]["question_id"] },
      function (data) {
        message_data = data;
        $.get("php/zerver_page_teacher_fetch_questions.php", function (data) {
          fetch_cq = JSON.parse(data);
          $("#thead-cq").empty();
          $("#thead-cq").append(
            "<tr><th>questions</th><th>HPS</th><th>time of issue</th><th>due date</th><th>status</th><th>actions</th></tr>"
          );
          $("#tbody-cq").empty();
          for (i in fetch_cq) {
            if (
              fetch_cq[i]["publish"] == "1" &&
              fetch_cq[i]["classroom_id"] == curr_room
            ) {
              $("#tbody-cq").append(
                "<tr><td>" +
                  fetch_cq[i]["question"] +
                  "</td><td>" +
                  fetch_cq[i]["HPS"] +
                  "</td><td>" +
                  fetch_cq[i]["time_of_issue"] +
                  "</td><td>" +
                  fetch_cq[i]["due_date"] +
                  "</td><td>" +
                  "PUBLISHED" +
                  "</td><td><img src='images/loading.gif' id='loading-publi_" +
                  fetch_cq[i]["question_id"] +
                  "' style='height: 30px; display: none;'><i class='delete-room material-icons' onclick='publish_unpublish(" +
                  fetch_cq[i]["question_id"] +
                  ")' data-toggle='tooltip' title='Unpublish?' >unpublished</i><i id='edit_q_" +
                  fetch_cq[i]["question_id"] +
                  "' class='delete-room material-icons' onclick='edit_question(" +
                  fetch_cq[i]["question_id"] +
                  ")'>edit</i><i class='delete-room material-icons' data-toggle='tooltip' title='Delete?' >delete</i></td></tr>"
              );
            } else if (
              fetch_cq[i]["publish"] == "0" &&
              fetch_cq[i]["classroom_id"] == curr_room
            ) {
              $("#tbody-cq").append(
                "<tr><td>" +
                  fetch_cq[i]["question"] +
                  "</td><td>" +
                  fetch_cq[i]["HPS"] +
                  "</td><td>" +
                  fetch_cq[i]["time_of_issue"] +
                  "</td><td>" +
                  fetch_cq[i]["due_date"] +
                  "</td><td>" +
                  "NOT PUBLISHED" +
                  "</td><td><img src='images/loading.gif' id='loading-publi_" +
                  fetch_cq[i]["question_id"] +
                  "' style='height: 30px; display: none;'><i class='delete-room material-icons' onclick='publish_unpublish(" +
                  fetch_cq[i]["question_id"] +
                  ")' data-toggle='tooltip' title='Publish?' >publish</i><i id='edit_q_" +
                  fetch_cq[i]["question_id"] +
                  "' class='delete-room material-icons' onclick='edit_question(" +
                  fetch_cq[i]["question_id"] +
                  ")'>edit</i><i class='delete-room material-icons' data-toggle='tooltip' title='Delete?' >delete</i></td></tr>"
              );
            }
          }
          alert(message_data);
        });
      }
    );
  } else if (fetch_cq[x]["publish"] == "0") {
    $.post(
      "php/zerver_page_teacher_question_publish.php",
      { id: fetch_cq[x]["question_id"] },
      function (data) {
        message_data = data;
        $.get("php/zerver_page_teacher_fetch_questions.php", function (data) {
          fetch_cq = JSON.parse(data);
          $("#thead-cq").empty();
          $("#thead-cq").append(
            "<tr><th>questions</th><th>HPS</th><th>time of issue</th><th>due date</th><th>status</th><th>actions</th></tr>"
          );
          $("#tbody-cq").empty();
          for (i in fetch_cq) {
            if (
              fetch_cq[i]["publish"] == "1" &&
              fetch_cq[i]["classroom_id"] == curr_room
            ) {
              $("#tbody-cq").append(
                "<tr><td>" +
                  fetch_cq[i]["question"] +
                  "</td><td>" +
                  fetch_cq[i]["HPS"] +
                  "</td><td>" +
                  fetch_cq[i]["time_of_issue"] +
                  "</td><td>" +
                  fetch_cq[i]["due_date"] +
                  "</td><td>" +
                  "PUBLISHED" +
                  "</td><td><img src='images/loading.gif' id='loading-publi_" +
                  fetch_cq[i]["question_id"] +
                  "' style='height: 30px; display: none;'><i class='delete-room material-icons' onclick='publish_unpublish(" +
                  fetch_cq[i]["question_id"] +
                  ")' data-toggle='tooltip' title='Unpublish?' >unpublished</i><i id='edit_q_" +
                  fetch_cq[i]["question_id"] +
                  "' class='delete-room material-icons' onclick='edit_question(" +
                  fetch_cq[i]["question_id"] +
                  ")'>edit</i><i class='delete-room material-icons'>delete</i></td></tr>"
              );
            } else if (
              fetch_cq[i]["publish"] == "0" &&
              fetch_cq[i]["classroom_id"] == curr_room
            ) {
              $("#tbody-cq").append(
                "<tr><td>" +
                  fetch_cq[i]["question"] +
                  "</td><td>" +
                  fetch_cq[i]["HPS"] +
                  "</td><td>" +
                  fetch_cq[i]["time_of_issue"] +
                  "</td><td>" +
                  fetch_cq[i]["due_date"] +
                  "</td><td>" +
                  "NOT PUBLISHED" +
                  "</td><td><img src='images/loading.gif' id='loading-publi_" +
                  fetch_cq[i]["question_id"] +
                  "' style='height: 30px; display: none;'><i class='delete-room material-icons' onclick='publish_unpublish(" +
                  fetch_cq[i]["question_id"] +
                  ")' data-toggle='tooltip' title='Publish?'>publish</i><i id='edit_q_" +
                  fetch_cq[i]["question_id"] +
                  "' class='delete-room material-icons' onclick='edit_question(" +
                  fetch_cq[i]["question_id"] +
                  ")'>edit</i><i class='delete-room material-icons' data-toggle='tooltip' title='Delete?' >delete</i></td></tr>"
              );
            }
          }
          alert(message_data);
          document.getElementById("loading-publi_" + input).style.display =
            "none";
        });
      }
    );
  }
}

function newstud_reject(input) {
  document.getElementById("loading_newstud_" + input).style.display = "inline";
  $.post(
    "php/zerver_page_teacher_decline_new_stud.php",
    { decline: input },
    function (data) {
      alert(data);
      location.reload();
    }
  );
}

function newstud_accept(input) {
  document.getElementById("loading_newstud_" + input).style.display = "inline";
  $.post(
    "php/zerver_page_teacher_accept_new_stud.php",
    { accept: input },
    function (data) {
      alert(data);
      location.reload();
    }
  );
}

function delete_room(input) {
  document.getElementById("chosen_room_" + input).style.display = "inline";
  document.getElementById("r-delete").value = input;
  on(1);
}

$("#create-room-btn").click(function () {
  if (
    document.getElementById("create-room").value == "" ||
    document.getElementById("code-room").value == ""
  ) {
    alert("Please enter room name and code...");
    return;
  } else {
    document.getElementById("create-room-load").style.display = "inline";
    $.post(
      "php/zerver_page_teacher_create_room.php",
      {
        roomname: document.getElementById("create-room").value,
        roomcode: document.getElementById("code-room").value,
      },
      function () {
        $.get("php/zerver_page_teacher_fetch_rooms.php", function (data) {
          fetch_rooms = JSON.parse(data);
          $("#tbody-lor").empty();
          for (i in fetch_rooms) {
            $("#tbody-lor").append(
              "<tr><td><img src='images/loading.gif' style='display: none; height: 30px' class='chosen_rooms' id='chosen_room_" +
                fetch_rooms[i]["room_id"] +
                "'>" +
                fetch_rooms[i]["room_name"] +
                "</td><td>" +
                fetch_rooms[i]["room_code"] +
                "</td><td class='see-room-studs-h'>" +
                "##" + //fetch_rooms[i][""]
                "<i class='see-room-studs material-icons'>visibility</i></td><td><i class='enter-room material-icons' onclick='room_enter(" +
                fetch_rooms[i]["room_id"] +
                ")'>meeting_room</i><i class='edit-room material-icons'>edit</i><i onclick='delete_room(" +
                fetch_rooms[i]["room_id"] +
                ")' class='delete-room material-icons'>delete</i></td></tr>"
            );
          }
        });
        document.getElementById("create-room-load").style.display = "none";
      }
    );
  }
});

hstart = 0;

function highlight(input) {
  $("#" + input).mousedown(function () {
    hstart = input.replace("se_ans_", "").split("_")[1];
    console.log(hstart);
    document.getElementById(input).style.color = "white";
    document.getElementById(input).style.backgroundColor = "rgb(184, 8, 8)";
  });
}

function stop_highlight(input) {
  document.getElementById(input).style.color = "white";
  document.getElementById(input).style.backgroundColor = "rgb(184, 8, 8)";
  therest = input.replace("se_ans_", "");
  therest_arr = therest.split("_");
  console.log(typeof hstart + " <-> " + typeof therest_arr[1]);
  if (Number(hstart) <= Number(therest_arr[1])) {
    for (
      x = therest_arr[1] - 1;
      x > -1 &&
      document.getElementsByClassName("se_ans_" + therest_arr[0])[x].style
        .backgroundColor != "rgb(184, 8, 8)";
      x--
    ) {
      document.getElementsByClassName("se_ans_" + therest_arr[0])[
        x
      ].style.color = "white";
      document.getElementsByClassName("se_ans_" + therest_arr[0])[
        x
      ].style.backgroundColor = "rgb(184, 8, 8)";
    }
  } else {
    for (
      x = Number(hstart) - 1;
      x > -1 &&
      document.getElementsByClassName("se_ans_" + therest_arr[0])[x].style
        .backgroundColor != "rgb(184, 8, 8)";
      x--
    ) {
      document.getElementsByClassName("se_ans_" + therest_arr[0])[
        x
      ].style.color = "white";
      document.getElementsByClassName("se_ans_" + therest_arr[0])[
        x
      ].style.backgroundColor = "rgb(184, 8, 8)";
    }
  }
}

function page_start() {
  $("#tbody-se").empty();
  for (x = 0; x < fetch_student_answers.length; x++) {
    arr_text = fetch_student_answers[x]["answer"].split(" ");
    spanned_text = "";
    for (i = 0; i < arr_text.length; i++) {
      spanned_text +=
        "<span id='se_ans_" +
        fetch_student_answers[x]["answer_id"] +
        "_" +
        i +
        "' class='se_ans_" +
        fetch_student_answers[x]["answer_id"] +
        "' onmouseover = 'highlight(this.id)' onmouseup = 'stop_highlight(this.id)'>" +
        arr_text[i] +
        " </span>";
    }
    if (fetch_student_answers[x]["re_eval"] == "1") {
      $("#tbody-se").append(
        "<tr><td style='text-align: center;'><img src='php/" +
          fetch_student_answers[x]["profile_pic_address"] +
          "' class='people-pic img-fluid' style='height: 60px;'><br>" +
          fetch_student_answers[x]["username"] +
          "</td><td><i class='edit-room material-icons' data-toggle='tooltip' data-placement='top' title='Requested Re-evaluation' style='font-size: 30px; color: red;'>priority_high</i></td><td>" +
          fetch_student_answers[x]["question"] +
          "<br><br><b>Room: " +
          fetch_student_answers[x]["room_name"] +
          "</b></td><td>" +
          spanned_text +
          "</td><td><input type = 'number' min='0' max='100' value='100' data-toggle='tooltip' data-placement='top' title='100% means perfect!'>%<br><br><i class='edit-room material-icons' data-toggle='tooltip' data-placement='top' title='Clear HIGHLIGHTS!'>backspace</i><button>DONE</button></td></tr>"
      );
    } else {
      $("#tbody-se").append(
        "<tr><td style='text-align: center;'><img src='php/" +
          fetch_student_answers[x]["profile_pic_address"] +
          "' class='people-pic img-fluid' style='height: 60px;'><br>" +
          fetch_student_answers[x]["username"] +
          "</td><td><i class='edit-room material-icons' data-toggle='tooltip' data-placement='top' title='Done answering' style='font-size: 30px; color: #9aa787'>grading</i></td><td>" +
          fetch_student_answers[x]["question"] +
          "<br><br><b>Room: " +
          fetch_student_answers[x]["room_name"] +
          "</b></td><td>" +
          spanned_text +
          "</td><td><input type = 'number' min='0' max='100' value='100' data-toggle='tooltip' data-placement='top' title='100% means perfect!'>%<br><br><i class='edit-room material-icons' data-toggle='tooltip' data-placement='top' title='Clear HIGHLIGHTS!'>backspace</i><button>DONE</button></td></tr>"
      );
    }
  }
  if (window.innerWidth < 830) {
    document.getElementById("teacher-sub-bar-tab1-1").style.display = "block";
    document.getElementById("teacher-sub-bar-tab2-2").style.display = "block";
    document.getElementById("teacher-sub-bar-tab3-3").style.display = "block";
    document.getElementById("teacher-sub-bar-tab1").style.display = "none";
    document.getElementById("teacher-sub-bar-tab2").style.display = "none";
    document.getElementById("teacher-sub-bar-tab3").style.display = "none";
    $("#thead-lor").empty();
    $("#thead-lor").append(
      "<tr><td>room name</td><td>room code</td><td>students</td><td>action</td></tr>"
    );
    $("#tbody-lor").empty();
    for (i in fetch_rooms) {
      $("#tbody-lor").append(
        "<tr><td><img src='images/loading.gif' style='display: none; height: 30px' class='chosen_rooms' id='chosen_room_" +
          fetch_rooms[i]["room_id"] +
          "'>" +
          fetch_rooms[i]["room_name"] +
          "</td><td>" +
          fetch_rooms[i]["room_code"] +
          "</td><td class='see-room-studs-h'>" +
          "##" + //fetch_rooms[i][""]
          "<i class='see-room-studs material-icons'>visibility</i></td><td><i class='enter-room material-icons' onclick='room_enter(" +
          fetch_rooms[i]["room_id"] +
          ")'>meeting_room</i><i class='edit-room material-icons'>edit</i><i onclick='delete_room(" +
          fetch_rooms[i]["room_id"] +
          ")' class='delete-room material-icons'>delete</i></td></tr>"
      );
    }
    $("#thead-newstud").empty();
    $("#thead-newstud").append(
      "<tr><th>action</th><th>time of issue</th><th>room name</th><th>new students</th></tr>"
    );
    $("#tbody-newstud").empty();
    for (i in fetch_newstud) {
      $("#tbody-newstud").append(
        "<tr><td>" +
          "<i class='decline-stud material-icons' onclick='newstud_reject(" +
          fetch_newstud[i]["t_s_conn_id"] +
          ")'>close</i><i class='accept-stud material-icons' onclick='newstud_accept(" +
          fetch_newstud[i]["t_s_conn_id"] +
          ")'>how_to_reg</i>" +
          "</td><td>" +
          fetch_newstud[i]["time_of_issue"] +
          "</td><td>" +
          fetch_newstud[i]["room_name"] +
          "</td><td>" +
          fetch_newstud[i]["student_email"] +
          "<img src='images/loading.gif' id='loading_newstud_" +
          fetch_newstud[i]["t_s_conn_id"] +
          "' style='height: 30px; display: none'></td><tr>"
      );
    }
    $("#thead-cq").empty();
    $("#thead-cq").append(
      "<tr><th>questions</th><th>HPS</th><th>time of issue</th><th>due date</th><th>status</th><th>actions</th></tr>"
    );
    $("#tbody-cq").empty();
  }
  if (window.innerWidth > 829) {
    document.getElementById("teacher-sub-bar-tab1-1").style.display = "none";
    document.getElementById("teacher-sub-bar-tab2-2").style.display = "none";
    document.getElementById("teacher-sub-bar-tab3-3").style.display = "none";
    document.getElementById("teacher-sub-bar-tab1").style.display = "block";
    document.getElementById("teacher-sub-bar-tab2").style.display = "block";
    document.getElementById("teacher-sub-bar-tab3").style.display = "block";
    $("#thead-lor").empty();
    $("#thead-lor").append(
      "<tr><th>room name</th><th>room code</th><th>students</th><th>action</th></tr>"
    );
    $("#tbody-lor").empty();
    for (i in fetch_rooms) {
      $("#tbody-lor").append(
        "<tr><td><img src='images/loading.gif' style='display: none; height: 30px' class='chosen_rooms' id='chosen_room_" +
          fetch_rooms[i]["room_id"] +
          "'>" +
          fetch_rooms[i]["room_name"] +
          "</td><td>" +
          fetch_rooms[i]["room_code"] +
          "</td><td class='see-room-studs-h'>" +
          "##" + //fetch_rooms[i][""]
          "<i class='see-room-studs material-icons'>visibility</i></td><td><i class='enter-room material-icons' onclick='room_enter(" +
          fetch_rooms[i]["room_id"] +
          ")'>meeting_room</i><i class='edit-room material-icons'>edit</i><i onclick='delete_room(" +
          fetch_rooms[i]["room_id"] +
          ")' class='delete-room material-icons'>delete</i></td></tr>"
      );
    }
    $("#thead-newstud").empty();
    $("#thead-newstud").append(
      "<tr><th>action</th><th>time of issue</th><th>room name</th><th>new students</th></tr>"
    );
    $("#tbody-newstud").empty();
    for (i in fetch_newstud) {
      $("#tbody-newstud").append(
        "<tr><td>" +
          "<i class='decline-stud material-icons' onclick='newstud_reject(" +
          fetch_newstud[i]["t_s_conn_id"] +
          ")'>close</i><i class='accept-stud material-icons' onclick='newstud_accept(" +
          fetch_newstud[i]["t_s_conn_id"] +
          ")'>how_to_reg</i>" +
          "</td><td>" +
          fetch_newstud[i]["time_of_issue"] +
          "</td><td>" +
          fetch_newstud[i]["room_name"] +
          "</td><td>" +
          fetch_newstud[i]["student_email"] +
          "<img src='images/loading.gif' id='loading_newstud_" +
          fetch_newstud[i]["t_s_conn_id"] +
          "' style='height: 30px;display: none'></td><tr>"
      );
    }
    $("#thead-cq").empty();
    $("#thead-cq").append(
      "<tr><th>questions</th><th>HPS</th><th>time of issue</th><th>due date</th><th>status</th><th>actions</th></tr>"
    );
    $("#tbody-cq").empty();
  }
  document.getElementById("teacher-rooms").style.display = "flex";
  document.getElementById("teacher-sub-bar-tab1").style.backgroundColor =
    "#5cdb95";
  document.getElementById("teacher-create").style.display = "none";
  document.getElementById("teacher-sub-bar-tab2").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-grades").style.display = "none";
  document.getElementById("teacher-sub-bar-tab3").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab1-1").style.backgroundColor =
    "#5cdb95";
  document.getElementById("teacher-sub-bar-tab2-2").style.backgroundColor =
    "#379683";
  document.getElementById("teacher-sub-bar-tab3-3").style.backgroundColor =
    "#379683";
}

$(window).resize(function () {
  page_start();
});

page_fetch_data();
page_fetch_grades();
